import turtle
playerx=0
playery=0
speed=10
numBox=0
player=turtle.Turtle()
message=turtle.Turtle()
window=turtle.Screen()
window.bgcolor("lightgray")

Box1=turtle.Turtle()
Box1.color("yellow")
Box1.speed(0)
Box1.penup()
Box1.goto(-200,-50)
Box1.pendown()
Box1.begin_fill()
Box1.forward(40)
Box1.left(90)
Box1.forward(40)
Box1.left(90)
Box1.forward(40)
Box1.left(90)
Box1.forward(40)
Box1.end_fill()
Box1x=-180
Box1y=-30
Box1.color("black")


def draw_message(text):
  message.speed(0)
  message.up()
  message.goto(-200,150)
  message.color('brown')
  message.down()
  message.begin_fill()
  message.forward(400)
  message.left(90)
  message.forward(50)
  message.left(90)
  message.forward(400)
  message.left(90)
  message.forward(50)
  message.left(90)
  message.end_fill()
  message.color('black')
  message.write(text,move=False,font=("Arial",20))
draw_message("Collect all the Boxes")

message.ht()
Box1.ht()
player.ht()

def collision():
  global playerx, playery, Box1x, Box1y,Box1
  if (playerx==Box1x) and (playery==Box1y):
    Box1.clear()
    message.clear()
    draw_message("You are the winner")

def drawplayer():
  player.clear()
  player.speed(0)
  player.up()
  player.goto(playerx,playery)
  player.dot(20,"navy")
  collision()

drawplayer()


def move_left():
  global playerx
  playerx=playerx-speed
  drawplayer()
  print(playerx)
  print(playery)

def move_right():
  global playerx
  playerx=playerx+speed
  drawplayer()
  print(playerx)
  print(playery)

def move_up():
  global playery
  playery=playery+speed
  drawplayer()
  print(playerx)
  print(playery)

def move_down():
  global playery
  playery=playery-speed
  drawplayer()
  print(playerx)
  print(playery)

window.onkey(move_up, "Up")
window.onkey(move_down, "Down")
window.onkey(move_left, "Left")
window.onkey(move_right, "Right")
window.listen()
window.mainloop()
